package com.example.awesomecom;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class LaptopAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Laptop> laptops;

    public LaptopAdapter(Context context) {
        this.context = context;
        laptops = new ArrayList<>();
    }

    public void setLaptops(ArrayList<Laptop> laptops) {
        this.laptops = laptops;
    }

    @Override
    public int getCount() {
        return laptops.size();
    }

    @Override
    public Object getItem(int i) {
        return laptops.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.item_laptop, viewGroup, false);
        }
        ViewHolder viewHolder = new ViewHolder(view);
        Laptop laptop = (Laptop) getItem(i);
        viewHolder.bind(laptop);
        return view;
    }

    private class ViewHolder {
        private TextView txtName;
        private TextView txtDescription;
        private ImageView imgPhoto;

        ViewHolder(View view) {
            txtName = view.findViewById(R.id.txt_name);
            txtDescription = view.findViewById(R.id.txt_description);
            imgPhoto = view.findViewById(R.id.img_photo);
        }

        void bind(Laptop laptop) {
            txtName.setText(laptop.getName());
            txtDescription.setText(laptop.getDescription());
            imgPhoto.setImageResource(laptop.getPhoto());
        }
    }
}

