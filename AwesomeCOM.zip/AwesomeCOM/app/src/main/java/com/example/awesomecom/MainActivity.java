package com.example.awesomecom;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Dictionary;

public class MainActivity extends AppCompatActivity {

    private String[] dataName;
    private String[] dataDescription;
    private TypedArray dataPhoto;
    private com.example.awesomecom.LaptopAdapter adapter;
    private ArrayList<Laptop> laptops;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        adapter = new com.example.awesomecom.LaptopAdapter(this);
        ListView listView = findViewById(R.id.lv_list);
        listView.setAdapter(adapter);
        prepare();
        addItem();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(MainActivity.this, laptops.get(i).getName(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void addItem() {
        laptops = new ArrayList<>();
        ArrayList<Laptop> laptops = new ArrayList<>();
        for (int i = 0; i < dataName.length; i++) {
            Laptop laptop = new Laptop();
            laptop.setPhoto(dataPhoto.getResourceId(i, -1));
            laptop.setName(dataName[i]);
            laptop.setDescription(dataDescription[i]);
            laptops.add(laptop);
        }
        adapter.setLaptops(laptops);
    }
    private void prepare() {
        dataName = getResources().getStringArray(R.array.data_name);
        dataDescription = getResources().getStringArray(R.array.data_description);
        dataPhoto = getResources().obtainTypedArray(R.array.data_photo);
    }
}
